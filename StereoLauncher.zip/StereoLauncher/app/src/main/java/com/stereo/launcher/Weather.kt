package com.stereo.launcher

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Clima por hora con Open-Meteo (gratis, sin clave). */
object Weather {
    data class Hour(val time: String, val temp: Int, val rain: Int, val code: Int)
    data class Result(val nowTemp: Int, val nowCode: Int, val hours: List<Hour>)

    fun fetch(lat: Double, lon: Double): Result {
        val url = URL(
            "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,weather_code" +
                "&hourly=temperature_2m,precipitation_probability,weather_code" +
                "&forecast_hours=6&timezone=auto"
        )
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 10000
        conn.readTimeout = 10000
        try {
            val j = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val cur = j.getJSONObject("current")
            val hr = j.getJSONObject("hourly")
            val times = hr.getJSONArray("time")
            val temps = hr.getJSONArray("temperature_2m")
            val rain = hr.getJSONArray("precipitation_probability")
            val codes = hr.getJSONArray("weather_code")
            val list = ArrayList<Hour>()
            // El índice 0 es la hora actual; mostramos las 5 siguientes.
            for (i in 1 until times.length()) {
                if (list.size == 5) break
                list.add(
                    Hour(
                        times.getString(i).substring(11, 16),
                        Math.round(temps.getDouble(i)).toInt(),
                        rain.optInt(i, 0),
                        codes.optInt(i, 0)
                    )
                )
            }
            return Result(
                Math.round(cur.getDouble("temperature_2m")).toInt(),
                cur.optInt("weather_code", 0),
                list
            )
        } finally {
            conn.disconnect()
        }
    }

    fun describe(code: Int): String = when (code) {
        0 -> "Despejado"
        1, 2 -> "Parcialmente nublado"
        3 -> "Nublado"
        45, 48 -> "Niebla"
        in 51..57 -> "Llovizna"
        in 61..67 -> "Lluvia"
        in 71..77 -> "Nieve"
        in 80..82 -> "Chubascos"
        in 95..99 -> "Tormenta"
        else -> "—"
    }

    fun icon(code: Int): Int = when (code) {
        0, 1 -> R.drawable.ic_sun
        2, 3, 45, 48, in 71..77 -> R.drawable.ic_cloud
        else -> R.drawable.ic_rain
    }
}
