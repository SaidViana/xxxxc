package com.stereo.launcher

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock

/** Sigue la sesión de música activa (YT Music, Spotify, etc.) y la controla. */
class MusicController(private val ctx: Context, private val ui: Ui) {

    interface Ui {
        fun onNoAccess()
        fun onIdle()
        fun onTrack(title: String, artist: String, art: Bitmap?, durationMs: Long)
        fun onState(playing: Boolean, positionMs: Long, speed: Float, at: Long)
    }

    private val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    private val cn = ComponentName(ctx, NotifListener::class.java)
    private var controller: MediaController? = null

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { pick(it) }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = pushMeta(metadata)
        override fun onPlaybackStateChanged(state: PlaybackState?) = pushState(state)
        override fun onSessionDestroyed() {
            try { pick(msm.getActiveSessions(cn)) } catch (_: SecurityException) { ui.onNoAccess() }
        }
    }

    fun start() {
        try {
            msm.addOnActiveSessionsChangedListener(sessionsListener, cn)
            pick(msm.getActiveSessions(cn))
        } catch (_: SecurityException) {
            ui.onNoAccess()
        }
    }

    fun stop() {
        try { msm.removeOnActiveSessionsChangedListener(sessionsListener) } catch (_: Exception) {}
        controller?.unregisterCallback(callback)
        controller = null
    }

    private fun pick(list: List<MediaController>?) {
        val c = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        controller?.unregisterCallback(callback)
        controller = c
        if (c == null) { ui.onIdle(); return }
        c.registerCallback(callback)
        pushMeta(c.metadata)
        pushState(c.playbackState)
    }

    private fun pushMeta(m: MediaMetadata?) {
        val title = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Sin título"
        val artist = m?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val art = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
        ui.onTrack(title, artist, art, m?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L)
    }

    private fun pushState(s: PlaybackState?) {
        ui.onState(
            s?.state == PlaybackState.STATE_PLAYING,
            s?.position ?: 0L,
            s?.playbackSpeed ?: 1f,
            s?.lastPositionUpdateTime ?: SystemClock.elapsedRealtime()
        )
    }

    fun toggle() {
        val c = controller ?: return
        if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
        else c.transportControls.play()
    }

    fun next() { controller?.transportControls?.skipToNext() }
    fun prev() { controller?.transportControls?.skipToPrevious() }
}
