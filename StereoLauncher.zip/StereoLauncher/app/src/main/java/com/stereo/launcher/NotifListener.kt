package com.stereo.launcher

import android.service.notification.NotificationListenerService

/**
 * Servicio vacío: Android exige un NotificationListener habilitado para que
 * una app pueda leer y controlar las sesiones de medios (música) activas.
 */
class NotifListener : NotificationListenerService()
