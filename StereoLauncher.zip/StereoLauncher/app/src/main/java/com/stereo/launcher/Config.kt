package com.stereo.launcher

/** Ajustes que puedes editar antes de compilar. */
object Config {
    // Coordenadas de respaldo para el clima si el stereo no entrega ubicación.
    // CAMBIA ESTOS VALORES por los de tu ciudad (los de ejemplo son de la Ciudad de México).
    const val LAT = 19.4326
    const val LON = -99.1332

    // Paquetes que se intentan abrir, en orden; se usa el primero instalado.
    val MAPS = listOf(
        "com.google.android.apps.maps", "com.waze",
        "com.autonavi.amapauto", "com.autonavi.minimap"
    )
    val YOUTUBE = listOf("com.google.android.youtube")
    val YT_MUSIC = listOf("com.google.android.apps.youtube.music")
}
