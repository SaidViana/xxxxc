package com.stereo.launcher

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.format.DateFormat
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), MusicController.Ui {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var music: MusicController

    private var noAccess = false
    private var playing = false
    private var posMs = 0L
    private var posAt = 0L
    private var speed = 1f
    private var durMs = 0L

    private val progressTick = object : Runnable {
        override fun run() { updateProgress(); handler.postDelayed(this, 1000) }
    }
    private val weatherTick = object : Runnable {
        override fun run() { refreshWeather(); handler.postDelayed(this, 30 * 60 * 1000L) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val pattern = DateFormat.getBestDateTimePattern(Locale.getDefault(), "EEEEdMMMM")
        findViewById<TextClock>(R.id.date).apply { format24Hour = pattern; format12Hour = pattern }

        music = MusicController(this, this)

        bind(R.id.dockMaps) { openFirst(Config.MAPS) }
        bind(R.id.mapCard) { openFirst(Config.MAPS) }
        bind(R.id.dockYt) { openFirst(Config.YOUTUBE, "https://www.youtube.com") }
        bind(R.id.dockMusic) { openFirst(Config.YT_MUSIC, "https://music.youtube.com") }
        bind(R.id.dockPhone) { go(Intent(Intent.ACTION_DIAL)) }
        bind(R.id.dockSettings) { go(Intent(Settings.ACTION_SETTINGS)) }
        bind(R.id.btnPlay) { music.toggle() }
        bind(R.id.btnNext) { music.next() }
        bind(R.id.btnPrev) { music.prev() }
        bind(R.id.musicInfo) {
            if (noAccess) go(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }

        requestPermissions(
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
            1
        )
        handler.post(weatherTick)
    }

    override fun onResume() {
        super.onResume()
        music.start()
        handler.post(progressTick)
    }

    override fun onPause() {
        music.stop()
        handler.removeCallbacks(progressTick)
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        }
    }

    // Un launcher no debe cerrarse con "atrás".
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {}

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        refreshWeather()
    }

    // ---------- Accesos ----------
    private fun bind(id: Int, action: () -> Unit) {
        findViewById<View>(id).setOnClickListener { action() }
    }

    private fun go(intent: Intent) {
        try { startActivity(intent) }
        catch (_: ActivityNotFoundException) { toast("No se pudo abrir") }
    }

    private fun openFirst(pkgs: List<String>, fallbackUrl: String? = null) {
        for (p in pkgs) {
            val i = packageManager.getLaunchIntentForPackage(p)
            if (i != null) { go(i); return }
        }
        if (fallbackUrl != null) go(Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl)))
        else toast("App no instalada")
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------- Clima ----------
    private fun currentLatLon(): Pair<Double, Double> {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            val lm = getSystemService(android.content.Context.LOCATION_SERVICE) as LocationManager
            for (p in listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)) {
                try {
                    lm.getLastKnownLocation(p)?.let { return it.latitude to it.longitude }
                } catch (_: Exception) {}
            }
        }
        return Config.LAT to Config.LON
    }

    private fun refreshWeather() {
        Thread {
            try {
                val (lat, lon) = currentLatLon()
                val r = Weather.fetch(lat, lon)
                runOnUiThread { showWeather(r) }
            } catch (_: Exception) {
                // Sin internet: se conserva lo último mostrado.
            }
        }.start()
    }

    private fun showWeather(r: Weather.Result) {
        findViewById<TextView>(R.id.tvNow).text = "${r.nowTemp}°"
        findViewById<TextView>(R.id.tvCond).text = Weather.describe(r.nowCode)
        findViewById<ImageView>(R.id.ivNow).setImageResource(Weather.icon(r.nowCode))
        val ids = listOf(R.id.h1, R.id.h2, R.id.h3, R.id.h4, R.id.h5)
        ids.forEachIndexed { i, id ->
            val v = findViewById<View>(id)
            val h = r.hours.getOrNull(i)
            if (h == null) { v.visibility = View.INVISIBLE; return@forEachIndexed }
            v.visibility = View.VISIBLE
            v.findViewById<TextView>(R.id.hHour).text = h.time
            v.findViewById<TextView>(R.id.hTemp).text = "${h.temp}°"
            v.findViewById<TextView>(R.id.hRain).text = "Lluvia ${h.rain}%"
            v.findViewById<ImageView>(R.id.hIcon).setImageResource(Weather.icon(h.code))
        }
    }

    // ---------- Música (MusicController.Ui) ----------
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun setTexts(title: String, artist: String) {
        findViewById<TextView>(R.id.tvSong).text = title
        findViewById<TextView>(R.id.tvArtist).text = artist
    }

    private fun setArt(bmp: Bitmap?) {
        val iv = findViewById<ImageView>(R.id.ivArt)
        if (bmp != null) {
            iv.setPadding(0, 0, 0, 0)
            iv.setImageBitmap(bmp)
        } else {
            iv.setPadding(dp(28), dp(28), dp(28), dp(28))
            iv.setImageResource(R.drawable.ic_music_dark)
        }
    }

    private fun setPlayIcon() {
        findViewById<ImageButton>(R.id.btnPlay)
            .setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
    }

    override fun onNoAccess() {
        noAccess = true; playing = false; durMs = 0; posMs = 0
        setTexts("Activar control de música", "Toca aquí y permite el acceso a notificaciones")
        setArt(null); setPlayIcon(); updateProgress()
    }

    override fun onIdle() {
        noAccess = false; playing = false; durMs = 0; posMs = 0
        setTexts("Sin reproducción", "Abre YT Music o tu reproductor")
        setArt(null); setPlayIcon(); updateProgress()
    }

    override fun onTrack(title: String, artist: String, art: Bitmap?, durationMs: Long) {
        noAccess = false
        durMs = durationMs
        setTexts(title, artist)
        setArt(art)
        updateProgress()
    }

    override fun onState(playing: Boolean, positionMs: Long, speed: Float, at: Long) {
        this.playing = playing; posMs = positionMs; this.speed = speed; posAt = at
        setPlayIcon(); updateProgress()
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    private fun updateProgress() {
        val cur = if (playing) posMs + ((SystemClock.elapsedRealtime() - posAt) * speed).toLong() else posMs
        val c = if (durMs > 0) cur.coerceIn(0, durMs) else cur.coerceAtLeast(0)
        findViewById<ProgressBar>(R.id.pb).progress = if (durMs > 0) (c * 1000 / durMs).toInt() else 0
        findViewById<TextView>(R.id.tvCur).text = fmt(c)
        findViewById<TextView>(R.id.tvDur).text = if (durMs > 0) fmt(durMs) else "--:--"
    }

}
