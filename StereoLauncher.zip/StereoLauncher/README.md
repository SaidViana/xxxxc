# Launcher Stereo

Launcher para stereos Android (probado en diseño 1024×600, Android 9).
Reloj, clima de las próximas 5 horas, control de música, mapa y accesos a YouTube / YT Music.

## Antes de compilar
Edita `app/src/main/java/com/stereo/launcher/Config.kt`:
- `LAT` y `LON`: coordenadas de tu ciudad (respaldo del clima).
- Paquetes de mapas/YouTube si tu stereo usa otras apps.

## Compilar el APK
**Opción A – GitHub (sin instalar nada):** sube esta carpeta a un repositorio nuevo.
En la pestaña *Actions* corre "Build APK" y descarga el artefacto `StereoLauncher-APK`.

**Opción B – Android Studio:** abre la carpeta, espera la sincronización y usa
*Build > Build APK(s)*. El archivo queda en `app/build/outputs/apk/debug/app-debug.apk`.

## Instalar en el stereo
1. Copia `app-debug.apk` a una memoria USB e instálalo (permite "orígenes desconocidos").
2. Pulsa Inicio y elige "Launcher Stereo" → "Siempre".
3. Toca la tarjeta de música y activa el acceso a notificaciones para "Launcher Stereo".
4. Acepta el permiso de ubicación para el clima local.
